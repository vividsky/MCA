import ADT.LinkedList;

public class Main {

    public static void main(String[] args) {
        LinkedList arr = new LinkedList();
        arr.insertAtFront("Ankit");
        arr.insertAtRear("Nidhi");
        arr.insertAtFront("Shraddha darlo");
        arr.delAtFront();
        arr.delAtRear();
        arr.display();
    }
}
